# Authors

DATA was initially written and is currently maintained by:

- [Samuel Weiser](mailto:samuel.weiser@iaik.tugraz.at)
- [Andreas Zankl](mailto:andreas.zankl@aisec.fraunhofer.de)

## Contributors

The following authors contributed code to DATA. Names are given in chronological order:

- Lukas Bodner
- David Schrammel
